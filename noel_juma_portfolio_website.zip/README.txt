NOEL JUMA PORTFOLIO WEBSITE

Files:
- index.html: page structure and portfolio content
- style.css: dark, responsive styling
- script.js: mobile navigation and automatic footer year

How to preview:
1. Keep all three files in the same folder.
2. Open index.html in a web browser.
3. Internet is only needed for the optional Google Fonts import; the site still works without it.

Before publishing, review the contact information and replace anything you do not want publicly displayed.
